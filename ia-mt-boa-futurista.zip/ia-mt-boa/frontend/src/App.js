
import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [message, setMessage] = useState('');
  const [reply, setReply] = useState('');

  const sendMessage = async () => {
    const res = await axios.post('http://localhost:3001/chat', { message });
    setReply(res.data.reply);
  };

  return (
    <div className="App">
      <h1>IA Futurista</h1>
      <textarea value={message} onChange={e => setMessage(e.target.value)} />
      <button onClick={sendMessage}>Enviar</button>
      <p>{reply}</p>
    </div>
  );
}

export default App;
